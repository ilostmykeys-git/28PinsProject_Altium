Place here zip file of source files, e.g copy and pack here directory from:
! ALtium Source Files\_ClientName\ProjectName_\V1I1